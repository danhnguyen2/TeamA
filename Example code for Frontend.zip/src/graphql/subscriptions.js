/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateVase = /* GraphQL */ `
  subscription OnCreateVase {
    onCreateVase {
      id
      painter
      shape
      entry
      location
      v_num
      notes
      height
      diameter
      plate
      reference
      description
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateVase = /* GraphQL */ `
  subscription OnUpdateVase {
    onUpdateVase {
      id
      painter
      shape
      entry
      location
      v_num
      notes
      height
      diameter
      plate
      reference
      description
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteVase = /* GraphQL */ `
  subscription OnDeleteVase {
    onDeleteVase {
      id
      painter
      shape
      entry
      location
      v_num
      notes
      height
      diameter
      plate
      reference
      description
      createdAt
      updatedAt
    }
  }
`;
