import React from 'react';
import './App.css';
import DisplayVases from './components/DisplayVases'

function App() {
  return (
    <div className="App">
      < DisplayVases />
    </div>
  );
}

export default App;
