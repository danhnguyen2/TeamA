import profile from '../src/images/pottery.jpg';

const details = [
	{
		name: "name",
		shape: "circular",
		about: "dummy",
		location: "spain",
		genre: "painter/potter",
		img: profile
	},
	{
		name: "name",
		shape: "circular",
		about: "dummy",
		location: "spain",
		genre: "painter/potter",
		img: profile
	},
	{
		name: "name",
		shape: "circular",
		about: "dummy",
		location: "spain",
		genre: "painter/potter",
		img: profile
	},
	{
		name: "name",
		shape: "circular",
		about: "dummy",
		location: "spain",
		genre: "painter/potter",
		img: profile
	},
	{
		name: "name",
		shape: "circular",
		about: "dummy",
		location: "spain",
		genre: "painter/potter",
		img: profile
	},
	{
		name: "name",
		shape: "circular",
		about: "dummy",
		location: "spain",
		genre: "painter/potter",
		img: profile
	},
	{
		name: "name",
		shape: "circular",
		about: "dummy",
		location: "spain",
		genre: "painter/potter",
		img: profile
	},
	{
		name: "name",
		shape: "circular",
		about: "dummy",
		location: "spain",
		genre: "painter/potter",
		img: profile
	}
];

export default details;